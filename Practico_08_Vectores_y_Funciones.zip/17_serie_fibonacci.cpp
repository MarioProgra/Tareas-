#include <iostream>
using namespace std;

void leer(int &n);
void generarFibonacci(unsigned long long v[], int n);
void mostrar(unsigned long long v[], int n);

int main() {
    int n;
    unsigned long long fib[100]; // Evita desbordamientos rapido
    leer(n);
    generarFibonacci(fib, n);
    mostrar(fib, n);
    return 0;
}

void leer(int &n) {
    do {
        cout << "Cantidad de terminos Fibonacci (0 < n <= 90): ";
        cin >> n;
    } while (n <= 0 || n > 90);
}

void generarFibonacci(unsigned long long v[], int n) {
    if (n > 0) v[0] = 0;
    if (n > 1) v[1] = 1;
    for (int i = 2; i < n; i++) {
        v[i] = v[i-1] + v[i-2];
    }
}

void mostrar(unsigned long long v[], int n) {
    cout << "Serie de Fibonacci: ";
    for (int i = 0; i < n; i++) cout << v[i] << " ";
    cout << endl;
}
