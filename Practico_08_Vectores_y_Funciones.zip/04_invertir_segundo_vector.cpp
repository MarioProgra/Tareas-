#include <iostream>
#include <string>
using namespace std;

void leer(int v[], int &n);
void mostrar(int v[], int n, string nombre);
void invertirVector(int A[], int B[], int n);

int main() {
    int n;
    int A[100], B[100];
    leer(A, n);
    invertirVector(A, B, n);
    mostrar(A, n, "Vector A Original");
    mostrar(B, n, "Vector B Invertido");
    return 0;
}

void leer(int v[], int &n) {
    cout << "Cantidad de elementos: "; cin >> n;
    for (int i = 0; i < n; i++) cin >> v[i];
}

void mostrar(int v[], int n, string nombre) {
    cout << nombre << ": [";
    for (int i = 0; i < n; i++) cout << v[i] << (i == n - 1 ? "" : ", ");
    cout << "]" << endl;
}

void invertirVector(int A[], int B[], int n) {
    for (int i = 0; i < n; i++) {
        B[i] = A[n - 1 - i];
    }
}
