#include <iostream>
#include <cmath>
using namespace std;

void leer(double v[], int &n);
void mayorDiferencia(double A[], int n);

int main() {
    int n;
    double A[100];
    leer(A, n);
    mayorDiferencia(A, n);
    return 0;
}

void leer(double v[], int &n) {
    do {
        cout << "Cantidad (n >= 2): "; cin >> n;
    } while (n < 2);
    for (int i = 0; i < n; i++) cin >> v[i];
}

void mayorDiferencia(double A[], int n) {
    double maxDiff = -1;
    double v1 = 0, v2 = 0;
    for (int i = 0; i < n - 1; i++) {
        double diff = abs(A[i+1] - A[i]);
        if (diff > maxDiff) {
            maxDiff = diff;
            v1 = A[i];
            v2 = A[i+1];
        }
    }
    cout << "Mayor diferencia: " << maxDiff << " (entre " << v1 << " y " << v2 << ")" << endl;
}
