#include <iostream>
#include <string>
using namespace std;

void leer(double v[], int &n);
void mostrar(double v[], int n, string msg);
void ordenarBurbuja(double v[], int n);

int main() {
    double A[100];
    int n;
    leer(A, n);
    mostrar(A, n, "Vector Original");
    ordenarBurbuja(A, n);
    mostrar(A, n, "Vector Ordenado");
    return 0;
}

void leer(double v[], int &n) {
    cout << "Cantidad: "; cin >> n;
    for (int i = 0; i < n; i++) cin >> v[i];
}

void mostrar(double v[], int n, string msg) {
    cout << msg << ": ";
    for (int i = 0; i < n; i++) cout << v[i] << " ";
    cout << endl;
}

void ordenarBurbuja(double v[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (v[j] > v[j+1]) {
                double temp = v[j];
                v[j] = v[j+1];
                v[j+1] = temp;
            }
        }
    }
}
