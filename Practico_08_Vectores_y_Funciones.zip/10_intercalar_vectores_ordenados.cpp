#include <iostream>
#include <string>
using namespace std;

void leer(int v[], int &n, string nombre);
void mostrar(int v[], int n, string nombre);
void intercalar(int A[], int n, int B[], int m, int C[], int &k);

int main() {
    int A[50], B[50], C[100], n, m, k;
    cout << "Nota: Ingrese los datos ya ordenados ascendente." << endl;
    leer(A, n, "A");
    leer(B, m, "B");
    intercalar(A, n, B, m, C, k);
    mostrar(C, k, "Vector C (Intercalado y ordenado)");
    return 0;
}

void leer(int v[], int &n, string nombre) {
    cout << "Tamanio de " << nombre << ": "; cin >> n;
    for(int i=0; i<n; i++) cin >> v[i];
}

void mostrar(int v[], int n, string nombre) {
    cout << nombre << ": ";
    for (int i = 0; i < n; i++) cout << v[i] << " ";
    cout << endl;
}

void intercalar(int A[], int n, int B[], int m, int C[], int &k) {
    int i = 0, j = 0;
    k = 0;
    while (i < n && j < m) {
        if (A[i] < B[j]) { C[k] = A[i]; i++; }
        else { C[k] = B[j]; j++; }
        k++;
    }
    while (i < n) { C[k] = A[i]; i++; k++; }
    while (j < m) { C[k] = B[j]; j++; k++; }
}
