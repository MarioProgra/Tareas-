#include <iostream>
#include <cmath>
using namespace std;

void CUADRATICA(double a, double b, double c) {
    double discriminante = (b * b) - (4 * a * c);
    
    if (discriminante > 0) {
        double raiz1 = (-b + sqrt(discriminante)) / (2 * a);
        double raiz2 = (-b - sqrt(discriminante)) / (2 * a);
        cout << "Raiz 1 = " << raiz1 << endl;
        cout << "Raiz 2 = " << raiz2 << endl;
    } else if (discriminante == 0) {
        double raiz_doble = -b / (2 * a);
        cout << "Raiz doble = " << raiz_doble << endl;
    } else {
        cout << "El sistema tiene raices complejas." << endl;
    }
}

int main() {
    double a, b, c;
    cout << "Ingrese los coeficientes a, b y c:" << endl;
    cin >> a >> b >> c;
    
    CUADRATICA(a, b, c);
    return 0;
}
