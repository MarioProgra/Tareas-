#include <iostream>
#include <string>
using namespace std;

// Funcion auxiliar simple para numeros hasta el 99
string convertir_a_palabras(int n) {
    string unidades[] = {"", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez", "once", "doce", "trece", "catorce", "quince", "dieciseis", "diecisiete", "dieciocho", "diecinueve"};
    string decenas[] = {"", "", "veinte", "treinta", "cuarenta", "cincuenta", "sesenta", "setenta", "ochenta", "noventa"};
    
    if (n < 20) return unidades[n];
    if (n < 100) {
        if (n % 10 == 0) return decenas[n/10];
        else return decenas[n/10] + " y " + unidades[n%10];
    }
    return "numero grande"; 
}

void NUM_LITERAL(double R) {
    int parte_entera = R;
    int parte_decimal = (R - parte_entera) * 100;
    
    // Logica simplificada enfocada en la fraccion
    cout << parte_entera << " " << parte_decimal << "/100 bolivianos" << endl;
}

int main() {
    double R;
    cout << "Ingrese una cantidad en bolivianos (ej. 1560.50): ";
    cin >> R;
    
    NUM_LITERAL(R);
    return 0;
}
