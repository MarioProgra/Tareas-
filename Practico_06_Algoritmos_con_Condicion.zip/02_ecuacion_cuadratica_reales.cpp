#include <iostream>
#include <cmath>
using namespace std;

void RAIZ_REAL(double a, double b, double c) {
    double discriminante = (b * b) - (4 * a * c);
    
    if (discriminante >= 0) {
        double x1 = (-b + sqrt(discriminante)) / (2 * a);
        double x2 = (-b - sqrt(discriminante)) / (2 * a);
        cout << "Las soluciones reales son:" << endl;
        cout << "x1 = " << x1 << endl;
        cout << "x2 = " << x2 << endl;
    } else {
        cout << "La ecuacion no tiene raices reales." << endl;
    }
}

int main() {
    double a, b, c;
    cout << "Ingrese coeficientes a, b, c: ";
    cin >> a >> b >> c;
    
    RAIZ_REAL(a, b, c);
    return 0;
}
