#include <iostream>
using namespace std;

void COSTO_CARTA(int P) {
    if (P > 0 && P <= 50) {
        cout << "Costo: Bs. 1.50" << endl;
    } else if (P > 50 && P <= 100) {
        cout << "Costo: Bs. 4.00" << endl;
    } else if (P > 100 && P <= 200) {
        cout << "Costo: Bs. 6.00" << endl;
    } else if (P > 200 && P <= 350) {
        cout << "Costo: Bs. 10.50" << endl;
    } else if (P > 350 && P <= 500) {
        cout << "Costo: Bs. 15.00" << endl;
    } else if (P > 500) {
        cout << "NO PUEDE ENVIAR COMO CARTA" << endl;
    } else {
        cout << "Peso invalido" << endl;
    }
}

int main() {
    int peso;
    cout << "Ingrese el peso de la carta en gramos (P): ";
    cin >> peso;
    
    COSTO_CARTA(peso);
    return 0;
}
