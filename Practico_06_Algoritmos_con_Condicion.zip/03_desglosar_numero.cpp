#include <iostream>
using namespace std;

void DESGLOSAR(int N) {
    if (N >= 0 && N < 10000) {
        int u = N % 10;
        N = N / 10;
        int d = N % 10;
        N = N / 10;
        int c = N % 10;
        N = N / 10;
        int m = N % 10;
        
        cout << "Unidades de mil (m): " << m << endl;
        cout << "Centenas (c): " << c << endl;
        cout << "Decenas (d): " << d << endl;
        cout << "Unidades (u): " << u << endl;
    } else {
        cout << "El numero debe ser positivo y menor que 10000." << endl;
    }
}

int main() {
    int numero;
    cout << "Ingrese un numero N (< 10000): ";
    cin >> numero;
    
    DESGLOSAR(numero);
    return 0;
}
