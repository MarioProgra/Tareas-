#include <iostream>
using namespace std;

void MENU_AREAS() {
    int opcion;
    cout << "1. Cuadrado" << endl;
    cout << "2. Circulo" << endl;
    cout << "3. Triangulo" << endl;
    cout << "Elija una opcion: ";
    cin >> opcion;
    
    if (opcion == 1) {
        double L;
        cout << "Ingrese el lado: "; cin >> L;
        cout << "Area = " << L * L << endl;
    } else if (opcion == 2) {
        double R;
        double Pi = 3.14159;
        cout << "Ingrese el radio: "; cin >> R;
        cout << "Area = " << Pi * R * R << endl;
    } else if (opcion == 3) {
        double B, H;
        cout << "Ingrese la base: "; cin >> B;
        cout << "Ingrese la altura: "; cin >> H;
        cout << "Area = " << (B * H) / 2.0 << endl;
    } else {
        cout << "Opcion invalida." << endl;
    }
}

int main() {
    MENU_AREAS();
    return 0;
}
