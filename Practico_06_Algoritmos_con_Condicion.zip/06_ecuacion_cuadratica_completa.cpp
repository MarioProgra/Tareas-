#include <iostream>
#include <cmath>
using namespace std;

void CUADRATICA_COMPLETA(double a, double b, double c) {
    double discriminante = (b * b) - (4 * a * c);
    
    if (discriminante > 0) {
        cout << "Tiene dos raices reales distintas." << endl;
        cout << "x1 = " << (-b + sqrt(discriminante)) / (2 * a) << endl;
        cout << "x2 = " << (-b - sqrt(discriminante)) / (2 * a) << endl;
    } else if (discriminante == 0) {
        cout << "Tiene una raiz doble." << endl;
        cout << "x = " << -b / (2 * a) << endl;
    } else {
        cout << "Tiene raices complejas (imaginarias)." << endl;
    }
}

int main() {
    double a, b, c;
    cout << "Ingrese los coeficientes a, b, c: ";
    cin >> a >> b >> c;
    
    CUADRATICA_COMPLETA(a, b, c);
    return 0;
}
